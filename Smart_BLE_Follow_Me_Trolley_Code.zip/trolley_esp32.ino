#include <NimBLEDevice.h>
#define IN1 26
#define IN2 27
#define IN3 14
#define IN4 12
#define ENA 25
#define ENB 33
#define TRIG 5
#define ECHO 18
#define BUZZER 23
#define SPEED 100
NimBLEClient*cl=nullptr;bool ok=false;void stopM(){digitalWrite(IN1,0);digitalWrite(IN2,0);digitalWrite(IN3,0);digitalWrite(IN4,0);ledcWrite(ENA,0);ledcWrite(ENB,0);}void fwd(){digitalWrite(IN1,1);digitalWrite(IN2,0);digitalWrite(IN3,1);digitalWrite(IN4,0);ledcWrite(ENA,SPEED);ledcWrite(ENB,SPEED);}float ds(){digitalWrite(TRIG,0);delayMicroseconds(2);digitalWrite(TRIG,1);delayMicroseconds(10);digitalWrite(TRIG,0);auto d=pulseIn(ECHO,1,30000);if(!d)return 999;return d*0.0343/2;}class CC: public NimBLEClientCallbacks{void onConnect(NimBLEClient*){ok=true;}void onDisconnect(NimBLEClient*,int){ok=false;}};bool conn(){auto s=NimBLEDevice::getScan();s->setActiveScan(true);s->start(2,false);auto r=s->getResults();for(int i=0;i<r.getCount();i++){auto dv=r.getDevice(i);if(dv&&dv->haveName()&&dv->getName()=="FOLLOW_ME"){if(!cl){cl=NimBLEDevice::createClient();cl->setClientCallbacks(new CC());}if(cl->connect(dv)){ok=true;s->clearResults();return true;}}}s->clearResults();return false;}void setup(){pinMode(IN1,1);pinMode(IN2,1);pinMode(IN3,1);pinMode(IN4,1);pinMode(TRIG,1);pinMode(ECHO,0);pinMode(BUZZER,1);ledcAttach(ENA,1000,8);ledcAttach(ENB,1000,8);NimBLEDevice::init("");}void loop(){if(cl&&!cl->isConnected())ok=false;if(!ok){stopM();digitalWrite(BUZZER,1);conn();delay(300);return;}digitalWrite(BUZZER,0);if(ds()<15)stopM();else fwd();delay(100);}