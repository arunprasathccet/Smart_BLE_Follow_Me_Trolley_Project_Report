#include <NimBLEDevice.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#define OLED_SDA 8
#define OLED_SCL 9
#define VIBRATION_PIN 2
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH,SCREEN_HEIGHT,&Wire,-1);
bool c=false,w=false;class CB: public NimBLEServerCallbacks{void onConnect(NimBLEServer*){c=true;} void onDisconnect(NimBLEServer*){c=false; NimBLEDevice::getAdvertising()->start();}};void sh(const char*a,const char*b){display.clearDisplay();display.setTextSize(2);display.setCursor(8,10);display.println(a);display.setTextSize(1);display.setCursor(8,40);display.println(b);display.display();}void setup(){pinMode(VIBRATION_PIN,OUTPUT);Wire.begin(OLED_SDA,OLED_SCL);display.begin(SSD1306_SWITCHCAPVCC,0x3C);NimBLEDevice::init("FOLLOW_ME");auto s=NimBLEDevice::createServer();s->setCallbacks(new CB());NimBLEDevice::getAdvertising()->start();sh("SMART","WAITING");}void loop(){if(c){sh("TROLLEY","CONNECTED");digitalWrite(VIBRATION_PIN,LOW);w=true;}else if(w){sh("TROLLEY","MISSING");digitalWrite(VIBRATION_PIN,HIGH);delay(200);digitalWrite(VIBRATION_PIN,LOW);delay(200);}else{sh("SMART","WAITING");delay(300);}}