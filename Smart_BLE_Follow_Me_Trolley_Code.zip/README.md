# Smart BLE Follow-Me Trolley
Band: XIAO ESP32-C3
Trolley: ESP32 Dev Module
Libraries: NimBLE-Arduino, Adafruit GFX, Adafruit SSD1306